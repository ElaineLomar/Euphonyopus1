export const vision = `
En Euphony Opus aspiramos a transformar el panorama empresarial colombiano, orquestando una sinfonía de innovación, humanismo y sostenibilidad...
`;

export const mission = `
Componer soluciones vanguardistas que fusionen tecnología, armonía y humanismo para transformar el mundo...
`;

export const values = [
  "Integridad y Transparencia",
  "Innovación y Creatividad",
  "Sostenibilidad y Responsabilidad Social",
  "Colaboración y Conexión Humana",
  "Aprendizaje Continuo (Filomatia)",
  "Bienestar Integral"
];